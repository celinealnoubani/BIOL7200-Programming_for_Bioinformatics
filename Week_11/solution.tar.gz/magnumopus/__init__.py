from magnumopus.mapping import map_reads_to_ref
