#!/usr/bin/env python3

from .sam import Read